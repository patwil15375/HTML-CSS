var yourName = prompt("What is your name?");
var firstLetter = yourName.slice(0,1); 
var restLetters = yourName.slice(1,yourName.length); 
var yourName = firstLetter.toUpperCase() + restLetters.toLowerCase(); 
alert("Hello, " + yourName + "!"); 

