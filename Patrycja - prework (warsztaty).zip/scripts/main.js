var myButton = document.querySelector('button');
var myHeading = document.querySelector('h1');

function setUserName() {
    var myName = prompt('Proszę, wpisz swoje imię');
    localStorage.setItem('name', myName);
    myHeading.textContent = 'Witam w Grecji, ' + myName;
  }
  if(!localStorage.getItem('name')) {
    setUserName();
  } else {
    var storedName = localStorage.getItem('name');
    myHeading.textContent = 'Witam w Grecji, ' + storedName;
  }
  myButton.onclick = function() {
    setUserName();
  } 
var myImage = document.querySelector('img');

myImage.onclick = function() {
    var mySrc = myImage.getAttribute('src');
    if(mySrc === 'ant2.jpg') {
      myImage.setAttribute ('src','20170809_141852.jpg');
    } else {
      myImage.setAttribute ('src','ant2.jpg');
    }
}
var myLine;
myLine = 'Kot'
// To jest komentarz


var kaWka = 'mleko';
if (kaWka === 'mleko') {
    alert ('Nie lubię mleka');
} else {
    alert ('Kozie mleko jest ohydne');
}

function multiply(num1,num2) {
    var result = num1 * num2;
    return result;
  }
  document.querySelector('html').onclick = function() {
    alert('Ouch! Przestań mnie szturchać!');
}